import os
import re
import uuid
import threading
from pathlib import Path

import requests
import yt_dlp
from flask import Flask, request

BOT_TOKEN = os.environ["BOT_TOKEN"]
WEBHOOK_URL = os.environ.get("WEBHOOK_URL", "").rstrip("/")
DOWNLOAD_DIR = Path("/tmp/downloads")
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)

URL_RE = re.compile(r"https?://\S+")

def tg(method, data=None, files=None):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/{method}"
    r = requests.post(url, data=data, files=files, timeout=120)
    r.raise_for_status()
    return r.json()

def send_text(chat_id, text):
    tg("sendMessage", {"chat_id": chat_id, "text": text})

def download_and_send(chat_id, url):
    job = DOWNLOAD_DIR / uuid.uuid4().hex
    template = str(job) + ".%(ext)s"
    try:
        send_text(chat_id, "⏳ جاري تحميل المقطع...")
        opts = {
            "outtmpl": template,
            "format": "best[ext=mp4]/best",
            "noplaylist": True,
            "max_filesize": 49 * 1024 * 1024,
            "quiet": True,
            "no_warnings": True,
        }
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            path = Path(ydl.prepare_filename(info))
            if not path.exists():
                # Some extractors can change the final extension.
                matches = list(DOWNLOAD_DIR.glob(job.name + ".*"))
                if matches:
                    path = matches[0]
        if not path.exists():
            raise RuntimeError("لم يتم العثور على الملف بعد التحميل.")

        if path.stat().st_size > 49 * 1024 * 1024:
            raise RuntimeError("حجم المقطع أكبر من الحد المسموح به للإرسال عبر البوت.")

        with path.open("rb") as f:
            tg(
                "sendVideo",
                {"chat_id": chat_id, "supports_streaming": "true"},
                files={"video": (path.name, f, "video/mp4")},
            )
    except Exception as e:
        send_text(chat_id, "❌ ما قدرت أحمل الرابط.\nتأكد أن الرابط عام وصحيح، وحاول مرة ثانية.")
        print("DOWNLOAD ERROR:", repr(e))
    finally:
        for p in DOWNLOAD_DIR.glob(job.name + ".*"):
            try:
                p.unlink()
            except Exception:
                pass

def handle_update(update):
    msg = update.get("message") or {}
    chat = msg.get("chat", {})
    chat_id = chat.get("id")
    text = msg.get("text", "").strip()
    if not chat_id:
        return

    if text.startswith("/start"):
        send_text(
            chat_id,
            "👋 هلا بك!\n\nأرسل رابط المقطع هنا، وأنا أحاول تحميله لك.\n\n"
            "يدعم المواقع التي يدعمها yt-dlp."
        )
        return

    if text.startswith("/help"):
        send_text(chat_id, "أرسل رابط المقطع فقط، وانتظر حتى يكتمل التحميل.")
        return

    m = URL_RE.search(text)
    if m:
        threading.Thread(
            target=download_and_send,
            args=(chat_id, m.group(0)),
            daemon=True,
        ).start()
    else:
        send_text(chat_id, "📎 أرسل رابط المقطع هنا.")

@app.get("/")
def health():
    return "OK", 200

@app.post("/webhook")
def webhook():
    update = request.get_json(silent=True) or {}
    threading.Thread(target=handle_update, args=(update,), daemon=True).start()
    return "OK", 200

def set_webhook():
    if WEBHOOK_URL:
        url = WEBHOOK_URL + "/webhook"
        result = tg("setWebhook", {"url": url})
        print("Webhook:", result)

if __name__ == "__main__":
    set_webhook()
    port = int(os.environ.get("PORT", "10000"))
    app.run(host="0.0.0.0", port=port)
