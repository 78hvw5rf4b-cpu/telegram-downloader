بوت تحميل مقاطع تيليجرام

1) ارفع هذه الملفات إلى GitHub:
   app.py
   requirements.txt
   Dockerfile

2) في Render أنشئ Web Service واربط مستودع GitHub.
   اختر Docker.
   اختر Free إذا كان متاحًا.

3) أضف Environment Variables:
   BOT_TOKEN = التوكن الخاص ببوتك
   WEBHOOK_URL = رابط Render الذي سيعطيك إياه، مثل:
                 https://اسم-الخدمة.onrender.com

4) Deploy.
   بعد نجاح التشغيل، أرسل /start للبوت ثم جرّب إرسال رابط عام.

مهم:
- لا تضع BOT_TOKEN داخل الملفات أو GitHub.
- البوت يعتمد على yt-dlp، لذلك المواقع المدعومة تتغير مع الوقت.
- هذا الإصدار يرفض الملفات الكبيرة جدًا للإرسال عبر Telegram.
